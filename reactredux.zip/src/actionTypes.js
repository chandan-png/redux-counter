export const INCREMENT = 'INCREMENT';
export const DECREASE = 'DECREASE';
